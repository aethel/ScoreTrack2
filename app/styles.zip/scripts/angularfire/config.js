angular.module('firebase.config', [])
  .constant('FBURL', 'https://scoretrack.firebaseio.com');
