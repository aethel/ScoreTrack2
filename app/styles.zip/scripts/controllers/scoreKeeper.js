"use strict";


angular.module('stApp').controller('ScoreCtrl', function($scope, InitData){
   $scope.init = InitData.getValue();
 
  
});